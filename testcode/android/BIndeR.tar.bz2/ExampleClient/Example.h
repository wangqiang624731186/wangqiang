// File: Example.h
#ifndef ANDROID_BYN_EXAMPLE_H
#define ANDROID_BYN_EXAMPLE_H

namespace android
{
    class Example {
    public:
        void add100(int n);
        private:
        static const void getExampleService();
    };
}; //namespace 
#endif // ANDROID_BYN_EXAMPLE_H

